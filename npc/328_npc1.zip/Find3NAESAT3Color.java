
/**
 * Class to hold functionality for deciding if p is an elemeent
 * of 3NAESAT by reducing it to a three-color problem.
 */
public class Find3NAESAT3Color {

    public static void main(String[] args) {
        System.out.println("Hello, world!");
    }
}
